import { JS_CONST } from "./helper";

export const HELP_2 = {
  HELP_2_TEXT: "HELP_2_TEXT",
  HELP_2_CONNECT: JS_CONST.TEST,
};

export default HELP_2;
