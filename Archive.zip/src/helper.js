import HELP_2 from "./helper_2";

export const JS_CONST = {
  TEST: "TEST",
  HELP_2: HELP_2.HELP_2_TEXT,
};

export function bar(url) {
  return url;
}
